function [ R11 ] = calculateR11(D1,R12)
        [row,~]=size(D1);
        R11 = eye(row);
        for ii = 1:row
            for j = ii+1:row
                setm1 = find(D1(ii,:)==1);
                setm2 = find(D1(j,:)==1);
                sumnumm1 = sum(D1(ii, :));
                sumnumm2 = sum(D1(j, :));
                
                summ1 = 0;
                if ~isempty(setm1) && ~isempty(setm2)
                    for k=1:length(setm1)
                        summ1 = summ1 + max(R12(setm1(k), setm2));
                    end
                else
                    summ1 = 0;
                end
                
                summ2 = 0;
                if ~isempty(setm2) && ~isempty(setm1)
                    for k =1:length(setm2)
                        summ2 = summ2 + max(R12(setm2(k), setm1));
                    end
                else
                    summ2 = 0;
                end
                
                if (sumnumm1 + sumnumm2) > 0
                    R11(ii, j) = (summ1 + summ2) / (sumnumm1 + sumnumm2);
                    R11(j, ii) = R11(ii, j);
                end
            end
        end

end