function [resultm,resultd]= cal_result_m_d(G1,G2,D1)
[row,dm]=size(G1);
[col,dd]=size(G2);
Cm=zeros(row,dm);
        t1 = select_th(G1);
        for j = 1:dm
            index_cm = find(G1(:,j)./t1>1);
            for ii = 1:length(index_cm)
                Cm(index_cm(ii),j) = G1(index_cm(ii),j);
            end
        end
        Cm(Cm>0)=1;
        Cd=zeros(col,dd);
        t2 = select_th(G2);
        for j = 1:dd
            index_cd = find(G2(:,j)./t2>1);
            for ii = 1:length(index_cd)
                Cd(index_cd(ii),j) = G2(index_cd(ii),j);
            end
        end
        Cd(Cd>0)=1;
        simm = sim_matrix(G1,row);
        simm(isnan(simm))=0;
        simd = sim_matrix(G2,col);
        simd(isnan(simd))=0;

   
cellm = cell(dm,1);
for x = 1:dm
    p_simm = zeros(row,row);
    for ii =1:row
        for j =1:row
            if sum(Cm(ii,x)&Cm(j,x)) == 1
                p_simm(ii,j) =simm(ii,j);
            end
        end
    end
    cellm{x} = p_simm;
end
celld = cell(dd,1);
for y =1:dd
    p_simd = zeros(col,col);
    for ii =1:col
        for j =1:col
            if sum(Cd(ii,y)&Cd(j,y)) == 1
                p_simd(ii,j) =simd(ii,j);
            end
        end
    end
    celld{y} = p_simd;
end
resultm=zeros(row,col);
resultd=zeros(row,col);
for x = 1:dm
    s_simm = sum(cellm{x},2);
    s_simm = repmat(s_simm,1,col);
    s_simd=sum(celld{y},2)';
    s_simd = repmat(s_simd,row,1);
    resultmm = (cellm{x}*D1)./max(s_simm,1e-10);
    resultdd = (D1*celld{x}')./max(s_simd,1e-10);
    resultm=resultm+resultmm;
    resultd=resultd+resultdd;
end
        resultm=resultm./dm;
        resultd=resultd./dd;
end