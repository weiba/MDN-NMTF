function [G1, G2, K, S11, S22] = trainMLNEYKaddG1G2KnewpaLKI (Y, R11, R22, D1, dm, dd, a1, a2, a3, r1, r2, r3, r4, r5, m1)

[m, n] = size(D1);
round = 0;
rng('shuffle');
G1 = abs(rand(m, dm));
G2 = abs(rand(n, dd));

% Calculating miRNA dynamic neighbor matrix K1
K1 = dynamicK(R11, m1);
% Calculating disease dynamic neighbor matrix K2
K2 = dynamicK(R22, m1);
R11d = 0.5 * (K1 + K1');
R22d = 0.5 * (K2 + K2');
Dm = 0.5 * diag(sum(K1) + sum(K1, 2)');
Dd = 0.5 * diag(sum(K2) + sum(K2, 2)');
L1 = Dm - R11d;
L2 = Dd - R22d;

S11 = abs(rand(dm, dm));
S11 = (S11+S11')/2;
S22 = abs(rand(dd, dd));
S22 = (S22+S22')/2;
K = abs(rand(dm, dd));

ob = a1*(sum(sum((R11-G1*S11*G1').^2)))+a2*(sum(sum((Y.*(D1-G1*K*G2')).^2)))...
    +a3*(sum(sum((R22-G2*S22*G2').^2)))+r1*trace(G1'*G1)+r2*trace(G2'*G2)+...
    r3*trace(G1'*L1*G1)+r4*trace(G2'*L2*G2)+r5*(sum(sum((K'*K-eye(dd)).^2)));
while round < 1000
    
    s1 = G1'*G1*S11*G1'*G1;
    S11 = S11.*((G1'*R11*G1)./(max(s1,1e-9)));
    s2 = G2'*G2*S22*G2'*G2;
    S22 = S22.*((G2'*R22*G2)./(max(s2,1e-9)));

    g1 = 2*a1*G1*S11*G1'*G1*S11+a2*Y.*(G1*K*G2')*G2*K'+r1*G1+r3*Dm*G1;
    G1 = G1.*((2*a1*R11*G1*S11+a2*Y.*D1*G2*K'+r3*R11d*G1)./(max(g1,1e-9)));
    
    g2 = 2*a3*G2*S22*G2'*G2*S22+a2*Y'.*(G2*K'*G1')*G1*K+r2*G2+r4*Dd*G2;
    G2 = G2.*((2*a3*R22*G2*S22+a2*Y'.*D1'*G1*K+r4*R22d*G2)./(max(g2,1e-9)));
     
    k = a2*G1'*(Y.*(G1*K*G2'))*G2+2*r5*K*K'*K;
    K = K.*sqrt((a2*(G1'*(Y.*D1)*G2)+2*r5*K)./(max(k,1e-9)));

    
    update_ob = a1*(sum(sum((R11-G1*S11*G1').^2)))+a2*(sum(sum((Y.*(D1-G1*K*G2')).^2)))...
        +a3*(sum(sum((R22-G2*S22*G2').^2)))+r1*trace(G1'*G1)+r2*trace(G2'*G2)+...
        r3*trace(G1'*L1*G1)+r4*trace(G2'*L2*G2)+r5*(sum(sum((K'*K-eye(dd)).^2)));
    
    e = abs(update_ob-ob)/update_ob;
    if e < 1e-6
        break;
    end
    ob = update_ob;
    round = round+1;
end
% fprintf('%d ', round);
end

