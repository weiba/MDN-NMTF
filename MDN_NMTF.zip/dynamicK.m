function X = dynamicK(S, thred)

[m, n] = size(S);
X = zeros(m, n);
miRNAneighbor = zeros(m,1);
for i =1: m
    [~,ii] = sort(S(i, :),'descend');
    num = 0;
    for j =1: length(ii)
        if ((1- S(i,ii(j)))/(j+1)) < (thred^(num+1))
            num = num + 1;
        else
            break
        end
        
        miRNAneighbor(i) = num;
    end
end
for i = 1:m
    if miRNAneighbor(i) > 0
        [~,ii] = sort(S(i, :),'descend');
        ii = ii(:,1:min(miRNAneighbor(i), n));
        X(i, ii) = S(i, ii);
    end
end

end