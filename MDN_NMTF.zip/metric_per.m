function [auc ] = metric_per( true_matrix,result_matrix)
[~,col]=size(true_matrix);
auc_list=zeros(1,col);
for i=1:col
    [auc]=newmetric(true_matrix(:,i),result_matrix(:,i));
    auc_list(i)=auc;
end
auc=mean(auc_list);
end