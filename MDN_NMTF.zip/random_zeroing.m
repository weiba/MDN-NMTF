clear();
for iindex = 2
    if iindex == 1
        strx = 'HMDD2.0-You';
        fprintf('%s:\n',strx);
    elseif iindex == 2
        strx = 'HMDD2.0-Yan';
        fprintf('%s:\n',strx);
    elseif iindex==3
        strx = 'HMDD2.0-Lan';
        fprintf('%s:\n',strx);
    else
        strx = 'HMDD3.0';
        fprintf('%s:\n',strx);
    end
    %     fid = fopen(strcat('parameters/mdn_random_',strx,'.txt'),'w');
    R12 = importdata(strcat('data/', strx, '-diseasesemsim.txt')); %Disease semantic similarity matrix
    R22in = importdata(strcat('data/', strx, '-diseasefunsim.txt')); %Disease functional similarity matrix
    D = importdata(strcat('data/', strx, '-miRNA-disease.txt')); %miRNA-disease association
    
    mirna = importdata('data/HMDD2.0-Yan-miRNA.txt');
    result_disease=zeros(576,2);

    [row,col] = size(D);
    R22in=R22in-diag(diag(R22in)-1);
    R12=R12-diag(diag(R12)-1);
    
    dm=200;dd=200;a1=0.001;a2=5;a3=0.1;
    r1=0.2;r2=0.8;r3 = 90;r4 = 1.5;r5 = 160;
    m1 = 0.56;
    n=20;per=5;
    
    [Index_zeroRow,Index_zeroCol] = find(D(:,:)==0);
    [Index_PositiveRow,Index_PositiveCol]=find(D(:,:)==1);
    
    totalassociation=length(Index_PositiveRow);
    totalper=fix(totalassociation/per);
    zero_length = length(Index_zeroRow);
    
    AAuc_list1=zeros(n,1);
    AAuc_list2=zeros(n,1);
    varAuc_list1 = zeros(n*per,1);
    varAuc_list2 = zeros(n*per,1);
    
    for time=1:n
        Auc_list1=zeros(per,1);
        Auc_list2=zeros(per,1);
        rng('shuffle');
        p=randperm(totalassociation); 
        for i=1:per
            D1 = D;
            W = D;
            W(W==0)=0.2;
            if i==per
                testset = p(((i-1)*totalper+1):totalassociation);
            else
                testset = p(((i-1)*totalper+1):i*totalper);
            end
            test_length = length(testset);
            true_list = zeros((test_length+zero_length),1);
            for c=1:test_length
                D1(Index_PositiveRow(testset(c)),Index_PositiveCol(testset(c)))=0;
                W(Index_PositiveRow(testset(c)),Index_PositiveCol(testset(c)))=0;
                true_list(c,1)=1;
            end
            
            % cacluate miRNA functional similarity matrix
            R11=calculateR11(D1,R12);
            % caclute GIP similarity matrices km and kd
            [km,kd] = gaussiansimilarity(D1,row,col);
            R22 = R22in;
            R11(R11 == 0) = km(R11 == 0);
            R22(R22in == 0) = kd(R22in == 0);
            R11sim=R11;
            R22sim=R22;
            R11=R11-diag(diag(R11));
            R22=R22-diag(diag(R22));
            
            [G1, G2, K, S11, S22] = trainMLNEYKaddG1G2KnewpaLKI (W, R11, R22, D1, dm, dd, a1, a2, a3, r1, r2, r3, r4, r5,  m1);
            %Calculate the resultm and resultd of simscore
            [resultm,resultd]= cal_result_m_d(G1,G2,D1);
            resultmd = resultm+resultd;
            resultm = (resultm-min(min(resultm)))./(max(max(resultm))-min(min(resultm)));
            resultd = (resultd-min(min(resultd)))./(max(max(resultd))-min(min(resultd)));
            result1 = G1*K*G2';
            result1n  = (result1-min(min(result1)))./(max(max(result1))-min(min(result1)));
            result2 = resultm./2+resultd./2+result1n;
            
%             casestudy
            result_disease = result_disease + result2(:,[168 251]);
            
            result_list1 = create_resultlist( result1,testset,Index_PositiveRow,Index_PositiveCol,Index_zeroRow,Index_zeroCol,test_length,zero_length );
            result_list2 = create_resultlist( result2,testset,Index_PositiveRow,Index_PositiveCol,Index_zeroRow,Index_zeroCol,test_length,zero_length );
            [auc1] = newmetric( true_list,result_list1 );
            [auc2] = newmetric( true_list,result_list2 );
            
            varAuc_list1((time - 1) * 5 +i,1) = auc1;
            varAuc_list2((time - 1) * 5 +i,1) = auc2;
            Auc_list1(i,1)=auc1;
            Auc_list2(i,1)=auc2;
        end
        AAuc_list1(time,1)=mean(Auc_list1);
        AAuc_list2(time,1)=mean(Auc_list2);
    end
    
    varAuc1 = std(varAuc_list1, 0, 1);
    varAuc2 = std(varAuc_list2, 0, 1);
    mauc1 = mean(AAuc_list1);
    mauc2 = mean(AAuc_list2);
    fprintf('auc = %f+%f\n', mauc1, varAuc1);
    fprintf('auc = %f+%f\n', mauc2, varAuc2);
%       casestudy
     result_dper = result_disease/100;
     [IX_col,R_col]=sort(result_dper,'descend');
     mirna_stomachneo=mirna(R_col(:,2));
     mirna_lymphomaneo=mirna(R_col(:,1));
    
    %             datax = [dm, dd, a1, a2, a3, r1, r2, r3, r4, r5, m1,mauc,varAuc];
    %             fprintf(fid,'%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f��%f\n',datax(1),datax(2),datax(3),datax(4),...
    %                 datax(5),datax(6),datax(7),datax(8),datax(9),datax(10),datax(11),datax(12),datax(13));
    
end

