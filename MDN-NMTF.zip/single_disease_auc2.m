function [aucx,x,y]=single_disease_auc2(disease_number,D,D1,result)
        [row,~]=size(D);
        sumD_col = sum(D(:,disease_number));
        trainD_col_length = sum(D1(:,disease_number));
        true_col = zeros(row-trainD_col_length,1);
        for c=1:sumD_col-trainD_col_length
            true_col(c,1)=1;
        end
        result_col=result(:,disease_number);
        all_col = find(D(:,disease_number)==1);
        train_col = find(D1(:,disease_number)==1);
        test_col = setdiff(all_col,train_col);
        zero_col=find(D(:,disease_number)==0);
        resultx=zeros(row-trainD_col_length,1);
        for ii=1:length(test_col)
            resultx(ii) = result_col(test_col(ii));
        end
        for ii=1:length(zero_col)
           resultx(ii+length(test_col)) =result_col(zero_col(ii));
        end
        [aucx,x,y]= newmetric2( true_col,resultx );
%         if isempty(test_col) || isempty(train_col)
        if isempty(test_col)
            aucx=-100;
        end
end