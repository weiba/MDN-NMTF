function [simm]= sim_matrix(G,k)
  simm = zeros(k,k);
  for j =1:k
      for i= 1:k
          simm(j,i) = simuv(G(j,:),G(i,:));
      end
  end
end