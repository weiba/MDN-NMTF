function [sim] = simuv(u,v)
    sim = sum(u.*v)/(norm(u,2)*norm(v,2));

end