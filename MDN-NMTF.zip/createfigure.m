function createfigure(i,X1, Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5, disease,figure1)
eval(['subplot',num2str(i),' = subplot(4,4,i,''Parent'',figure1);']);
eval(['hold(subplot',num2str(i),',''on'');']);
eval(['h1=plot(X1,Y1,''DisplayName'',''MDN-NMTF'',''LineWidth'',2,''Color'',[1 0 0],''Parent'',subplot',num2str(i),');']);
eval(['h2=plot(X2,Y2,''DisplayName'',''DNRLMF-MDA'',''LineWidth'',2,''Color'',[0.87058824300766 0.490196079015732 0],''Parent'',subplot',num2str(i),');']);
eval(['h3=plot(X3,Y3,''DisplayName'',''UBiRW'',''LineWidth'',2,''Color'',[0 0.800000011920929 1],''Parent'',subplot',num2str(i),');']);
eval(['h4=plot(X4,Y4,''DisplayName'',''IMCMDA'',''LineWidth'',2,''Color'',[0.200000002980232 0.600000023841858 0],''Parent'',subplot',num2str(i),');']);
eval(['h5=plot(X5,Y5,''DisplayName'',''GRNMF'',''LineWidth'',2,''Color'',[0.494117647409439 0.184313729405403 0.556862771511078],''Parent'',subplot',num2str(i),');']);
xlabel('FPR');
title(disease);
ylabel('TPR');
eval(['box(subplot',num2str(i),',''on'');']);
eval(['set(subplot',num2str(i),',''FontSize'',10,''LineWidth'',2,''XTick'',[0 0.5 1],''YTick'',[0 0.5 1],''YTickLabel'',{''0'',''0.5'',''1''});'])
if i==14
    legend1 = legend(subplot14,'show');
    set(legend1,'FontSize',12);
end
set(gca,'child',[h1 h2 h3 h4 h5])
