function tt = select_th(H)
[n, k] = size(H);
H_mean = sum(H,2) / k;
for i = 1:n
    H_std(i) = sqrt(sum((H(i,:) - H_mean(i)) .^2) / (k-1));   
end
H_std = H_std';
tt = H_mean + 1.5 * H_std;
end