Wei, P.,Du, J.L., et al. Predicting miRNA-disease association based on modularity preserving heterogeneous network embedding.

Run the following codes:
random_zeroing.m:
    The AUC values of MDN-NMTF and MDN-NMTF2 in four datasets at randomly zeroing 5-fold cross validation.
random_zeroing_col.m:
    The AUC values of MDN-NMTF and MDN-NMTF2 for 14 diseases in four datasets at randomly zeroing 5-fold cross validation.
single_column_zeroing.m:
    The AUC values of MDN-NMTF and MDN-NMTF2 in four datasets at single-column zeroing 5-fold cross validation.
plotauc.m:
    The ROC curves of MDN-NMTF for 14 diseases in HMDD2.0-Yan datasets at randomly zeroing 5-fold cross validation.
    