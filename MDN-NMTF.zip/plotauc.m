clear();
dname = {'Breast Neoplasms','Non-Small-Cell Lung Carcinoma','Renal Cell Carcinoma',...
    'Glioblastoma','Heart Failure','Hepatocellular Carcinoma','Lung Neoplasms',...
    'Melanoma','Neoplasms','Ovarian Neoplasms','Pancreatic Neoplasms',...
    'Prostatic Neoplasms','Stomach Neoplasms','Colorectal Neoplasms'};
figure1 = figure('Color',[1 1 1]);
for i =1:14
   eval(['[x1] = textread(''auc/mdnx',num2str(i),'.txt'',''%f'');']); 
   eval(['[y1] = textread(''auc/mdny',num2str(i),'.txt'',''%f'');']);
   eval(['[x2] = textread(''auc/dnrx',num2str(i),'.txt'',''%f'');']); 
   eval(['[y2] = textread(''auc/dnry',num2str(i),'.txt'',''%f'');']);
   eval(['[x3] = textread(''auc/doublex',num2str(i),'.txt'',''%f'');']); 
   eval(['[y3] = textread(''auc/doubley',num2str(i),'.txt'',''%f'');']);
   eval(['[x4] = textread(''auc/imcx',num2str(i),'.txt'',''%f'');']); 
   eval(['[y4] = textread(''auc/imcy',num2str(i),'.txt'',''%f'');']);
   eval(['[x5] = textread(''auc/grnx',num2str(i),'.txt'',''%f'');']); 
   eval(['[y5] = textread(''auc/grny',num2str(i),'.txt'',''%f'');']);
   createfigure(i,x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,dname(i),figure1);
end