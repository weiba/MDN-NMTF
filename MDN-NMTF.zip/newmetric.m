function [auc] = newmetric(ground_truth,predict )

pos_num = sum(ground_truth==1);
neg_num = sum(ground_truth==0);
m=size(ground_truth,1);
[~,Index]=sort(predict);
ground_truth=ground_truth(Index);
x=zeros(m+1,1);y=zeros(m+1,1);
auc=0;
x(1)=1;y(1)=1;
TP=sum(ground_truth(2:m)==1);
FP=sum(ground_truth(2:m)==0);

for i=2:m
    if i~=2
        if ground_truth(i-1)==1
            TP=TP-1;
        else
            FP=FP-1;
        end
    end
    if neg_num==0
        x(i)=0;
    else
        x(i)=FP/neg_num;
    end
    if pos_num==0
        y(i)=0;
    else
        y(i)=TP/pos_num;
    end
    auc=auc+(y(i)+y(i-1))*(x(i-1)-x(i))/2;
end

% fid = fopen(strcat('C:\Users\Flint\Desktop\auc\mdnxYou.txt'),'w');
% fprintf(fid,'%f ',x);
% fclose(fid);
% fid = fopen(strcat('C:\Users\Flint\Desktop\auc\mdnyYou.txt'),'w');
% fprintf(fid,'%f ',y);
% fclose(fid);
auc=auc+y(m)*x(m)/2;

end