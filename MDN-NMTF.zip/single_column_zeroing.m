clear();
for iindex = 1:4
   if iindex == 1
        strx = 'HMDD2.0-You';
        fprintf('%s:\n',strx);
    elseif iindex == 2
        strx = 'HMDD2.0-Yan';
        fprintf('%s:\n',strx);
    elseif iindex==3
        strx = 'HMDD2.0-Lan';
        fprintf('%s:\n',strx);
    else
        strx = 'HMDD3.0';
        fprintf('%s:\n',strx);
    end
    %     fid = fopen(strcat('parameters/single_col_',strx,'.txt'),'w');
    R12 = importdata(strcat('data/', strx, '-diseasesemsim.txt'));
    R22in = importdata(strcat('data/', strx, '-diseasefunsim.txt'));
    D = importdata(strcat('data/', strx, '-miRNA-disease.txt'));
    [row,col] = size(D);
    R22in=R22in-diag(diag(R22in)-1);
    R12=R12-diag(diag(R12)-1);
    
    dm=200;dd=200;a1=0.001;a2=5;a3=0.1;
    r1=0.2;r2=0.8;r3 = 90;r4 = 1.5;r5 = 160;
    m1 = 0.56;
    
    n = 1;                                          
    per = col;
    
    sD_col=sum(D);
    [disease_sort,index_sD_col] = sort(sD_col,'descend');
    
    disease_list2 = 1:col;
    totalassociation=col;
    totalper=fix(totalassociation/per);
    disease_length=col;
    
    AAuc_list1=zeros(n,1);
    AAuc_list2=zeros(n,1);
    var_auc1 = zeros(n*col,1);
    var_auc2 = zeros(n*col,1);
    for ii=1:disease_length
        eval(['Auc_listd',num2str(ii),'=zeros(n,1);']);
        eval(['Auc_listdx',num2str(ii),'=zeros(n,1);']);
    end
    
    for time=1:n
        Auc_list1=zeros(per,1);
        Auc_list2=zeros(per,1);
        rng('shuffle');
        p=index_sD_col;
        for i=1:per
            D1 = D;
            W = D;
            W(W==0)=0.2;
            testset = p(i);
            trainset = setdiff(p,testset);
            test_length = length(testset);
            for c=1:test_length
                D1(:,disease_list2(testset(c)))=0;
                W(:,disease_list2(testset(c)))=0;
            end
            R11=calculateR11(D1,R12);%
            [km,kd] = gaussiansimilarity(D1,row,col);%
            R22  = R22in;
            R11(R11 == 0) = km(R11 == 0);
            R22(R22in == 0) = kd(R22in == 0);
            R11=R11-diag(diag(R11));
            R22=R22-diag(diag(R22));
            
            
              [G1, G2, K, S11, S22] = trainMLNEYKaddG1G2KnewpaLKI (W, R11, R22, D1, dm, dd, a1, a2, a3, r1, r2, r3, r4, r5, m1);
            [resultm,resultd]= cal_result_m_d(G1,G2,D1);
            resultmd = resultm+resultd;
            resultm = (resultm-min(min(resultm)))./(max(max(resultm))-min(min(resultm)));
            resultd = (resultd-min(min(resultd)))./(max(max(resultd))-min(min(resultd)));
            result1 = G1*K*G2';
            result1n  = (result1-min(min(result1)))./(max(max(result1))-min(min(result1)));
            result2 = resultm./2+resultd./2+result1n;
            
            true_matrix = D(:,disease_list2(testset));
            result_matrix1 = result1(:,disease_list2(testset));
            result_matrix2 = result2(:,disease_list2(testset));
            [auc1] = metric_per(true_matrix,result_matrix1);
            [auc2] = metric_per(true_matrix,result_matrix2);
            
            eval(['Auc_listd',num2str(i),'(time,1)=auc1;']);
            eval(['Auc_listdx',num2str(i),'(time,1)=auc2;']);
            
            Auc_list1(i,1)=auc1;
            Auc_list2(i,1)=auc2;
            var_auc1((time-1)*per+i,1)=auc1;
            var_auc2((time-1)*per+i,1)=auc2;
            
        end
        AAuc_list1(time,1)=mean(Auc_list1);
        AAuc_list2(time,1)=mean(Auc_list2);
        
    end
%     diary(strcat('parameters/mul_col_grnmf',strx,'.txt'));
%     diary on
    fprintf('\nG1*K*G2 = %f+%f\n', mean(AAuc_list1),std(var_auc1,0,1))
    fprintf('resultm(norm)./2+resultd(norm)./2+G1*K*G2(norm) = %f+%f\n', mean(AAuc_list2),std(var_auc2,0,1))
    for ii=1:disease_length
        fprintf('%d\t%d\t',index_sD_col(ii),disease_sort(ii));
        eval(['Auc_listd',num2str(ii),'(Auc_listd',num2str(ii),'==-100)=[];']);
        eval(['fprintf','(''aucd',num2str(ii),'=\t%f\t''','',',mean(Auc_listd',num2str(ii),')',')']);
        eval(['Auc_listdx',num2str(ii),'(Auc_listdx',num2str(ii),'==-100)=[];']);
        eval(['fprintf','(''aucdx',num2str(ii),'=\t%f\n''','',',mean(Auc_listdx',num2str(ii),')',')']);
    end
%     diary off
    
end


